![Screenshot 1](https://github.com/mpakus/github-pr/blob/main/screenshot.png?raw=true)

GitHub PR - A simple tool to approve/decline pull requests on GitHub.

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/mpakus/github-pr)
[![License](https://img.shields.io/github/license/mpakus/github-pr?style=for-the-badge&logo=github&logoColor=white)](https://github.com/mpakus/github-pr/blob/main/LICENSE)
[![Downloads](https://img.shields.io/github/downloads/mpakus/github-pr/total)](https://github.com/mpakus/github-pr/releases)
[![Stars](https://img.shields.io/github/stars/mpakus/github-pr?style=social)](https://github.com/mpakus/github-pr/stargazers)
[![Issues](https://img.shields.io/github/issues/mpakus/github-pr?style=social)](https://github.com/mpakus/github-pr/issues)
[![PRs](https://img.shields.io/github/issues-pr/mpakus/github-pr?style=social)](https://github.com/mpakus/github-pr/pulls)
[![Version](https://img.shields.io/github/v/release/mpakus/github-pr?style=social)](https://github.com/mpakus/github-pr/releases)

![Screenshot 1](https://github.com/mpakus/github-pr/blob/main/screen1.png?raw=true)

![Screenshot 2](https://github.com/mpakus/github-pr/blob/main/screen2.png?raw=true)
