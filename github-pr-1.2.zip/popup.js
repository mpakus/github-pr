let approveBtn = document.getElementById('approveBtn');
let cancelBtn = document.getElementById('cancelBtn');

function clickApprove(e) {
	e.preventDefault();

  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		var activeTab = tabs[0];

		chrome.scripting.executeScript({
			target: { tabId: activeTab.id },
			func: function() {
				let userName = document.querySelector('[data-hovercard-type="user"]').innerText;
				document.getElementById('review-changes-modal').open = true;
				document.querySelectorAll('.js-review-changes')[0].click();
				document.getElementById('pull_request_review[event]_approve').click();
				let textDescription = document.getElementById('pull_request_review_body');

				let messages = ['looks good', 
					'I think we should merge this', 
					'this is looking great to me!',
												'looks good to me overall',
												 "We'll get this merged",
												  'This change LGTM', 
												  'This looks good',
												   'This looks good to me!',
												"Cool, let's go for it",
					'LGTM (Looks Good To Me)',
					'Code looks solid',
					'Ship it!',
					'great work!',
					'Approved, well done!',
					'Ready to merge, thanks!',
					'Thumbs up for a job well done!',
					'Reviewed and approved, go ahead and merge.',
					'This is good to go.',
					'Code is clean and functional, approved!',
					"Let's merge this, good job!",
					'Ship it!',
					'No issues found, approving for merge.',
					'Looks good on my end!',
					"+solid changes, go ahead and merge.",
					"Approved with minor suggestions, feel free to address them.",
					"Good to merge, thanks.",
					"Ready to ship, go ahead and merge when ready.",
					"All good, ship it!",
					"Approved, nice improvements!",
					"LGTM, merge it!",
					"Well done, approving for merge.",
					"Code looks great!",
					"Ready to merge after the tests are over.",
					"Solid changes, approved",
					"Ready for merge, no issues found.",
					"LGTM, merging after CI passes."
					];


				let msg = messages[Math.floor(Math.random() * messages.length)];

				textDescription.value = `@${userName} ${msg} :+1:`;
				textDescription.focus();					
			}
		});
  });
}

function clickCancel(e) {
	e.preventDefault();

  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		var activeTab = tabs[0];

		chrome.scripting.executeScript({
			target: { tabId: activeTab.id },
			func: function() { 
				let userName = document.querySelector('[data-hovercard-type="user"]').innerText;
				document.getElementById('review-changes-modal').open = true;
				document.querySelectorAll('[name="pull_request_review[event]"]')[2].click();
				document.getElementById('pull_request_review[event]_reject').click();
				let textDescription = document.getElementById('pull_request_review_body');

				let messages = [
					"This looks good! I've left a few comments that should be addressed before this gets merged ",
					'I left some comments about changes we need', 
					'looks good, just a few suggestions',
					"Appreciate your effort, but some aspects need more refinement.",
					"This PR needs to follow our coding standards more closely.",
					"This change needs to align with our overall architecture.",
					"Please address the comments in the PR before we can proceed.",
					"Kindly resolve the comments left on the PR for approval.",
					"Once the comments are addressed, we can merge this PR.",
					"Please take care of the PR comments first.",
					"The PR will be ready to merge after the comments are resolved.",
					"Ensure all PR comments are addressed for approval.",
					"Please finalize the comments in the PR.",
					"Address the feedback in the PR for it to be merged.",
					"Resolve the PR comments to proceed.",
					"Complete the comments in the PR before merging.",
					"Please finish addressing the comments in the PR.",
					"The PR is pending until all comments are resolved.",
					"Ensure comments are addressed before we can merge.",
					"PR comments need to be resolved first.",
					"Complete the requested changes in the comments for approval.",
					"Address the remaining comments to proceed with the PR.",
					"The PR can be merged after comments are handled.",
					"Finish the comment resolutions for the PR to be approved.",
					"Please resolve the outstanding comments in the PR.",
					"Once comments are addressed, we can move forward with this PR."
				];
				let msg = messages[Math.floor(Math.random() * messages.length)];

				textDescription.value = `@${userName} ${msg}`;
				textDescription.focus();					
			}
		});
  });
}


approveBtn.addEventListener('click', clickApprove);
cancelBtn.addEventListener('click', clickCancel);
